"""
lesson_bot.py - بوت تليجرام متكامل
  1) تصفح الشباتر والدروس من مجلد telegram_lesson_bot
  2) إضافة حساب (تسجيل دخول وحفظه)
  3) بدء الحل التلقائي على المنصة
"""

import os
import json
import re
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    Application,
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)
from playwright.async_api import async_playwright, TimeoutError as PWTimeout

# ────────────────────────────── إعدادات ──────────────────────────────

DATA_DIR = Path(os.environ.get("LESSON_DATA_DIR", Path(__file__).parent / "telegram_lesson_bot"))
ACCOUNTS_FILE = Path(__file__).parent / "accounts.json"

SITE_URL = os.getenv("SITE_URL", "https://me-portal.qureo.education/login")
HEADLESS = os.getenv("HEADLESS", "true").lower() == "true"

# حالات المحادثة
ASK_USER, ASK_PASS = range(2)

# ────────────────────────────── أدوات الحسابات ──────────────────────────────

def load_account(user_id: int) -> dict:
    if not ACCOUNTS_FILE.exists():
        return {}
    try:
        data = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
        return data.get(str(user_id), {})
    except Exception:
        return {}

def save_account(user_id: int, username: str, password: str):
    data = {}
    if ACCOUNTS_FILE.exists():
        try:
            data = json.loads(ACCOUNTS_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    data[str(user_id)] = {"user": username, "pass": password}
    ACCOUNTS_FILE.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

# ────────────────────────────── أدوات قراءة الملفات ──────────────────────────────

def _natural_key(s: str):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]

def get_chapters() -> list[Path]:
    if not DATA_DIR.exists():
        return []
    dirs = [d for d in DATA_DIR.iterdir() if d.is_dir() and d.name.startswith("chapter")]
    return sorted(dirs, key=lambda d: _natural_key(d.name))

def read_json(file_path: Path) -> dict:
    try:
        return json.loads(file_path.read_text(encoding="utf-8"))
    except Exception:
        return {}

def get_chapter_title(chapter_dir: Path) -> str:
    ch_file = chapter_dir / "chapter.json"
    if ch_file.exists():
        data = read_json(ch_file)
        if "chapter_title" in data:
            return data["chapter_title"]
    return chapter_dir.name

def get_lessons_in_chapter(chapter_dir: Path) -> list[dict]:
    lessons = []
    files = sorted(
        [f for f in chapter_dir.glob("*.json") if f.name != "chapter.json"],
        key=lambda f: _natural_key(f.name)
    )
    for f in files:
        data = read_json(f)
        title = data.get("lesson_title", data.get("title", f.stem))
        lessons.append({
            "id": f.stem,
            "title": title,
            "questions": data.get("questions", [])
        })
    return lessons

def all_answers_from_all_chapters() -> list[dict]:
    result = []
    for ch_dir in get_chapters():
        for lesson in get_lessons_in_chapter(ch_dir):
            for q in lesson["questions"]:
                if (q.get("answer") or "").strip():
                    result.append(q)
    return result

def chunk(text: str, limit: int = 3800) -> list[str]:
    text = text or "لا يوجد محتوى نصي."
    return [text[i : i + limit] for i in range(0, len(text), limit)]

# ────────────────────────────── Playwright ──────────────────────────────

async def pw_login(page, username: str, password: str) -> bool:
    try:
        await page.goto(SITE_URL, wait_until="domcontentloaded")
        pass_sel = "input[type=password]"
        await page.wait_for_selector(pass_sel, timeout=15000)

        user_sel = (
            "input[type=email], input[name*=user i], input[id*=user i], "
            "input[name*=email i], input[id*=email i], "
            "input[type=text], input[type=tel], input[type=number]"
        )
        await page.locator(user_sel).first.fill(username)
        await page.locator(pass_sel).first.fill(password)

        submit = page.locator("button[type=submit], input[type=submit]")
        if await submit.count():
            await submit.first.click()
        else:
            await page.locator(pass_sel).first.press("Enter")

        await page.wait_for_load_state("networkidle")
        await page.wait_for_timeout(2000)

        still = page.locator(pass_sel)
        if "login" in page.url.lower() and await still.count() and await still.first.is_visible():
            return False
        return True
    except Exception:
        return False

async def pw_list_lessons(page) -> list[str]:
    links = await page.locator("a[href*='lesson'], a[href*='course'], a[href*='chapter']").all()
    urls = []
    for a in links:
        href = await a.get_attribute("href")
        if href and href not in urls:
            urls.append(href)
    return urls

async def pw_solve_lesson(page, lesson_url: str, answers: list[dict]) -> dict:
    await page.goto(lesson_url, wait_until="domcontentloaded")
    await page.wait_for_timeout(1500)

    solved = 0
    skipped = 0

    for ans in answers:
        answer_text = (ans.get("answer") or "").strip()
        if not answer_text:
            skipped += 1
            continue

        field = page.locator("textarea:visible, input[type=text]:visible").first
        try:
            if await field.count():
                await field.fill(answer_text)
                solved += 1
                await page.wait_for_timeout(250)
            else:
                skipped += 1
        except Exception:
            skipped += 1

    submit = page.locator("button[type=submit]:visible, button:has-text('إرسال'):visible, button:has-text('حفظ'):visible")
    if await submit.count():
        try:
            await submit.first.click()
            await page.wait_for_timeout(800)
        except Exception:
            pass

    return {"url": lesson_url, "solved": solved, "skipped": skipped}

# ────────────────────────────── تصفح الشباتر ──────────────────────────────

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_chapters(update, context, 0)

async def show_chapters(update: Update, context: ContextTypes.DEFAULT_TYPE, page_num: int):
    chapters_dirs = get_chapters()
    total = len(chapters_dirs)
    start_i = page_num * 8
    buttons = []
    
    for i, ch_dir in enumerate(chapters_dirs[start_i : start_i + 8], start_i):
        title = get_chapter_title(ch_dir)
        buttons.append([InlineKeyboardButton(f"{i+1}. {title}", callback_data=f"c:{i}")])

    nav = []
    if page_num > 0:
        nav.append(InlineKeyboardButton("⬅️ السابق", callback_data=f"p:{page_num - 1}"))
    if start_i + 8 < total:
        nav.append(InlineKeyboardButton("التالي ➡️", callback_data=f"p:{page_num + 1}"))
    if nav:
        buttons.append(nav)

    # الأزرار الأساسية المطلوبة
    buttons.append([InlineKeyboardButton("➕ إضافة حساب", callback_data="add_account")])
    buttons.append([InlineKeyboardButton("🚀 ابدأ الحل", callback_data="start_solve")])

    msg = f"📚 عندك {total} شابتر.\nاختار شابتر لعرض دروسه، أو استخدم الأزرار تحت."
    markup = InlineKeyboardMarkup(buttons)

    if update.callback_query:
        await update.callback_query.edit_message_text(msg, reply_markup=markup)
    else:
        await update.message.reply_text(msg, reply_markup=markup)

async def show_lesson_content(q, lesson_data, chapter_index, lesson_index):
    cards = []
    for number, item in enumerate(lesson_data.get("questions", []), 1):
        prompt = (item.get("question") or "").strip()
        answer = (item.get("answer") or "").strip()
        if not prompt and not answer:
            continue
        answer_text = answer or "لا توجد إجابة صريحة."
        cards.append(f"السؤال {number}:\n{prompt}\n\nالإجابة:\n{answer_text}")

    if not cards:
        cards = ["لا توجد أسئلة في هذا الملف."]

    heading = f"{lesson_data.get('title', '')}\n\n"
    parts = chunk(heading + "\n\n──────────\n\n".join(cards))
    
    await q.edit_message_text(parts[0])
    for part in parts[1:-1]:
        await q.message.reply_text(part)
    await q.message.reply_text(
        parts[-1],
        reply_markup=InlineKeyboardMarkup(
            [[InlineKeyboardButton("🔙 العودة للدروس", callback_data=f"c:{chapter_index}")]]
        ),
    )

async def callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    key = q.data

    if key == "start_solve":
        acc = load_account(update.effective_user.id)
        if not acc:
            await q.edit_message_text("⚠️ مفيش حساب محفوظ. اضغط على '➕ إضافة حساب' الأول.")
            return
        await q.edit_message_text("⏳ جاري بدء الحل باستخدام حسابك المحفوظ...")
        await perform_solving(update, context, acc["user"], acc["pass"])
        return

    if key.startswith("p:"):
        await show_chapters(update, context, int(key[2:]))
        return

    chapters_dirs = get_chapters()
    
    if key.startswith("c:"):
        n = int(key[2:])
        ch_dir = chapters_dirs[n]
        lessons = get_lessons_in_chapter(ch_dir)
        
        rows = [
            [InlineKeyboardButton(f"{i+1}. {x['title']}", callback_data=f"l:{n}:{i}")]
            for i, x in enumerate(lessons)
        ]
        rows.append([InlineKeyboardButton("🔙 رجوع", callback_data="p:0")])
        
        await q.edit_message_text(
            f"{get_chapter_title(ch_dir)}\nاختار الدرس:",
            reply_markup=InlineKeyboardMarkup(rows),
        )
        return

    if key.startswith("l:"):
        _, cn, ln = key.split(":")
        cn, ln = int(cn), int(ln)
        ch_dir = chapters_dirs[cn]
        lessons = get_lessons_in_chapter(ch_dir)
        lesson = lessons[ln]
        await show_lesson_content(q, lesson, cn, ln)

# ────────────────────────────── Conversation: إضافة حساب ──────────────────────────────

async def add_account_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    await q.edit_message_text("ابعتلي اسم المستخدم (اليوزر) على المنصة:")
    return ASK_USER

async def add_account_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data["temp_user"] = update.message.text.strip()
    await update.message.reply_text("تمام، ابعتلي الباسورد دلوقتي:")
    return ASK_PASS

async def add_account_pass(update: Update, context: ContextTypes.DEFAULT_TYPE):
    username = context.user_data.get("temp_user")
    password = update.message.text.strip()
    
    try:
        await update.message.delete()
    except Exception:
        pass
        
    status_msg = await update.message.reply_text("⏳ جاري التحقق من الحساب...")
    
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=HEADLESS)
        page = await browser.new_page()
        success = await pw_login(page, username, password)
        await browser.close()

    if success:
        save_account(update.effective_user.id, username, password)
        await status_msg.edit_text("✅ تم إضافة الحساب بنجاح!")
    else:
        await status_msg.edit_text("❌ فشل إضافة الحساب. تأكد من اليوزر والباسورد.")
        
    context.user_data.pop("temp_user", None)
    return ConversationHandler.END

async def cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.clear()
    await update.message.reply_text("تم الإلغاء.")
    return ConversationHandler.END

# ────────────────────────────── الحل التلقائي ──────────────────────────────

async def perform_solving(update: Update, context: ContextTypes.DEFAULT_TYPE, username, password):
    msg = await update.effective_message.reply_text("🌐 فتح المنصة...")
    
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=HEADLESS)
            ctx_pw = await browser.new_context()
            page = await ctx_pw.new_page()

            if not await pw_login(page, username, password):
                await msg.edit_text("❌ فشل تسجيل الدخول بالحساب المحفوظ.")
                await browser.close()
                return

            await msg.edit_text("✅ تم الدخول. بجيب روابط الدروس...")
            lesson_urls = await pw_list_lessons(page)
            
            if not lesson_urls:
                await msg.edit_text("⚠️ مفيش دروس ظاهرة في الصفحة. (تأكد من سيليكتور الدروس في الكود)")
                await browser.close()
                return

            all_answers = all_answers_from_all_chapters()
            if not all_answers:
                await msg.edit_text("⚠️ مفيش إجابات في ملفات JSON.")
                await browser.close()
                return

            await msg.edit_text(f"📚 لقيت {len(lesson_urls)} درس. ببدأ الحل...")

            report = []
            for idx, url in enumerate(lesson_urls, 1):
                try:
                    res = await pw_solve_lesson(page, url, all_answers)
                    report.append(f"{idx}. ✅ {url}\n   حل: {res['solved']} | متخطي: {res['skipped']}")
                except Exception as e:
                    report.append(f"{idx}. ❌ {url}\n   خطأ: {e}")

                if idx % 3 == 0 or idx == len(lesson_urls):
                    tail = "\n".join(report[-4:])
                    await msg.edit_text(f"⏳ شغال على الدرس {idx}/{len(lesson_urls)}...\n\n{tail}")

            final_report = f"✅ خلصت {len(lesson_urls)} درس!\n\n" + "\n".join(report)
            for part in chunk(final_report):
                await update.effective_message.reply_text(part)

            await browser.close()
    except Exception as e:
        await msg.edit_text(f"❌ خطأ غير متوقع: {e}")

# ────────────────────────────── main ──────────────────────────────

def main():
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("Missing TELEGRAM_BOT_TOKEN. اضبطها كمتغير بيئة.")

    app = Application.builder().token(token).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(callback, pattern="^(p:|c:|l:|start_solve)$"))

    # Conversation لإضافة الحساب
    conv_handler = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_account_start, pattern="^add_account$")],
        states={
            ASK_USER: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_account_user)],
            ASK_PASS: [MessageHandler(filters.TEXT & ~filters.COMMAND, add_account_pass)],
        },
        fallbacks=[CommandHandler("cancel", cancel)],
    )
    app.add_handler(conv_handler)

    print("Bot is running. Press Ctrl+C to stop.")
    app.run_polling()

if __name__ == "__main__":
    main()